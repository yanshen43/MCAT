// Copyright 2009, Andreas Biegert

#include "amino_acid.h"

namespace cs {

const char AminoAcid::amino_acids_[] = "ARNDCQEGHILKMFPSTWYV";

}  // namespace cs
