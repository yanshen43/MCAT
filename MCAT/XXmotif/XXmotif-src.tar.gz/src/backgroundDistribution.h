#ifndef BACKGROUND
#define BACKGROUND
#include "Globals.h"

/********************************* PUBLIC *******************************/
void setBackgroundDistribution();

/********************************* PRIVATE *******************************/
void set_bg_kmer_dist();
void checkSequenceSet();

#endif
